import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level10 = new Level({
    size: [1500, 2000],
    objects: [
        new Player({
            pos: [50, 100],
            size: [50, 50]
        }),
        new Goal({
            pos: [1125, 50],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 1000, 
            y: 200, 
            r: 12, 
            value: 10 
        }),
        new Rectangle({
            pos: [700, 0],
            size: [100, 1900],
            color: "blue",
        }),
        new Rectangle({
            pos: [200, 500],
            size: [500, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [0, 500],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [0, 700],
            size: [600, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 900],
            size: [600, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [0, 1100],
            size: [600, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 1300],
            size: [600, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [0, 1500],
            size: [300, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [400, 1500],
            size: [300, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 1700],
            size: [600, 10],
            color: "blue",
        }),
        new Box({
            pos: [100, 1310],
            size: [300, 40],
            color: "magenta",
        }),
        new Box({
            pos: [100, 710],
            size: [300, 40],
            color: "magenta",
        }),
        new Coin({ 
            x: 500, 
            y: 1200, 
            r: 12, 
            value: 1 
        }),
        new Box({
            pos: [100, 1910],
            size: [120, 120],
            color: "magenta",
        }),
        new Rectangle({
            pos: [1100, 1750],
            size: [100, 10],
            color: "yellow",
        }),
        new Rectangle({
            pos: [1100, 1500],
            size: [100, 10],
            color: "yellow",
        }),
        new Rectangle({
            pos: [1100, 1250],
            size: [100, 10],
            color: "yellow",
        }),
        new Rectangle({
            pos: [1100, 1000],
            size: [100, 10],
            color: "yellow",
        }),
        new Rectangle({
            pos: [1100, 750],
            size: [100, 10],
            color: "yellow",
        }),
        new Rectangle({
            pos: [1100, 500],
            size: [100, 10],
            color: "yellow",
        }),
        new Rectangle({
            pos: [1100, 250],
            size: [100, 10],
            color: "yellow",
        }),

    ],
    
})