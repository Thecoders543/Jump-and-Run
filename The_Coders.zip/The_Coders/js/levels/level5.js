import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level5 = new Level({
    size: [2000, 1200],
    objects: [
        new Player({
            pos: [100, 1000],
            size: [50, 50]
        }),
        new Goal({
            pos: [10, 10],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 400, 
            y: 200, 
            r: 12, 
            value: 3 
        }),
        new Rectangle({
            pos: [1800, 900],
            size: [80, 80],
            color: "blue",
        }),
        new Box({
            pos: [300, 1000],
            size: [60, 60],
            color: "orange",
        }),
        new Rectangle({
            pos: [1600, 800],
            size: [70, 70],
            color: "blue",
        }),
        new Rectangle({
            pos: [1400, 700],
            size: [60, 60],
            color: "blue",
        }),
        new Rectangle({
            pos: [1200, 600],
            size: [50, 50],
            color: "blue",
        }),
        new Rectangle({
            pos: [800, 700],
            size: [40, 40],
            color: "blue",
        }),
        new Rectangle({
            pos: [600, 500],
            size: [30, 30],
            color: "blue",
        }),
        new Rectangle({
            pos: [400, 400],
            size: [20, 20],
            color: "blue",
        }),
        new Rectangle({
            pos: [200, 200],
            size: [10, 10],
            color: "blue",
        }),

    ],
    
})