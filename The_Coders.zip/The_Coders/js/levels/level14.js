import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level14 = new Level({
    size: [800, 600],
    objects: [
        new Player({
            pos: [100, 500],
            size: [60, 10]
        }),
        new Goal({
            pos: [750, 550],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 750, 
            y: 400, 
            r: 12, 
            value: 1 
        }),
        new Rectangle({
            pos: [700, 500],
            size: [100, 20],
            color: "red",
        }),
        new Rectangle({
            pos: [690, 500],
            size: [20, 20],
            color: "red",
        }),
        new Rectangle({
            pos: [690, 530],
            size: [20, 70],
            color: "red",
        }),
    ],
    
})