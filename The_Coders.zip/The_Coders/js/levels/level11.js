import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level11 = new Level({
    size: [1000, 600],
    objects: [
        new Player({
            pos: [100, 500],
            size: [60, 20]
        }),
        new Goal({
            pos: [700, 250],
            size: [30, 30],
            color: "black",
        }),
        new Rectangle({
            pos: [200, 330],
            size: [100, 10],
            color: "blue",
        }),
        new Coin({ 
            x: 500, 
            y: 300, 
            r: 12, 
            value: 2 
        }),
        new Box({
            pos: [900, 500],
            size:  [20, 20],
            color: "orange",
        })
    ],
    
})