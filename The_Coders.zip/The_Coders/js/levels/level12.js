import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level12 = new Level({
    size: [2000, 600],
    objects: [
        new Player({
            pos: [100, 500],
            size: [60, 20]
        }),
        new Goal({
            pos: [1950, 0],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 1200, 
            y: 30, 
            r: 12, 
            value: 3 
        }),
        new Rectangle({
            pos: [0, 400],
            size: [300, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [400, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [600, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [800, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1000, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1200, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1400, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1600, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1800, 400],
            size: [300, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [200, 200],
            size: [200, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [500, 200],
            size: [200, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [800, 200],
            size: [200, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1100, 200],
            size: [200, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1400, 200],
            size: [200, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1700, 200],
            size: [200, 10],
            color: "blue",
        }),
    ],
    
})