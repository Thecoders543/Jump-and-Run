import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level6 = new Level({
    size: [1000, 2000],
    objects: [
        new Player({
            pos: [100, 1800],
            size: [100, 100]
        }),
        new Goal({
            pos: [700, 100],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 950, 
            y: 800, 
            r: 12, 
            value: 2 
        }),
        new Box({
            pos: [500, 1700],
            size: [250, 250],
            color: "magenta",
        }),
        new Rectangle({
            pos: [700, 1700],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [500, 1500],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [300, 1300],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 1100],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [300, 1000],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [500, 750],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [700, 600],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [700, 400],
            size: [100, 10],
            color: "blue",
        }),

    ],
    
})