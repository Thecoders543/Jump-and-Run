import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level15 = new Level({
    size: [800, 1200],
    objects: [
        new Player({
            pos: [100, 1100],
            size: [60, 10]
        }),
        new Goal({
            pos: [600, 70],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 0, 
            y: 100, 
            r: 12, 
            value: 3 
        }),
        new Rectangle({
            pos: [400, 1000],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [200, 800],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [500, 600],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [200, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Box({
            pos: [200, 370],
            size: [30, 30],
            color: "orange"
        })
    ],
    
})