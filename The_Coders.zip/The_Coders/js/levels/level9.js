import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level9 = new Level({
    size: [3000, 1500],
    objects: [
        new Player({
            pos: [2900, 100],
            size: [50, 50]
        }),
        new Goal({
            pos: [1000, 600],
            size: [30, 30],
            color: "black",
        }),
        new Coin({ 
            x: 500, 
            y: 600, 
            r: 12, 
            value: 4 
        }),
        new Box({
            pos: [2000, 700],
            size: [800, 800],
            color: "green",
        }),
        new Box({
            pos: [2600, 100],
            size: [200, 200],
            color: "green",
        }),
        new Box({
            pos: [2200, 100],
            size: [400, 400],
            color: "green",
        }),
        new Box({
            pos: [1600, 100],
            size: [600, 600],
            color: "green",
        }),

    ],
    
})