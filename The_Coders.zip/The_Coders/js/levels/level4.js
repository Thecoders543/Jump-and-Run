import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level4 = new Level({
    size: [2000, 1000],
    objects: [
        new Player({
            pos: [100, 800],
            size: [50, 50]
        }),
        new Goal({
            pos: [1900, 100],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 1900, 
            y: 950, 
            r: 12, 
            value: 2 
        }),
        new Rectangle({
            pos: [300, 800],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [700, 600],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1200, 500],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [1600, 400],
            size: [100, 10],
            color: "blue",
        }),

    ],
    
})

// Nur Bei Game.js, die level importieren und unten die 