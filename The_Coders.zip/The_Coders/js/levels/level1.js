import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level1 = new Level({
    size: [800, 600],
    objects: [
        new Player({
            pos: [100, 500],
            size: [50, 50]
        }),
        new Goal({
            pos: [700, 250],
            size: [30, 30],
            color: "black",
        }),
        new Rectangle({
            pos: [200, 400],
            size: [100, 10],
            color: "blue",
        }),
        new Coin({ 
            x: 50, 
            y: 200, 
            r: 12, 
            value: 3 
        }),
    ],
    
})