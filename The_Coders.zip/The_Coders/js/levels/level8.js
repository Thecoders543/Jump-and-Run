import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level8 = new Level({
    size: [800, 600],
    objects: [
        new Player({
            pos: [0, 590],
            size: [10, 10]
        }),
        new Goal({
            pos: [790, 50],
            size: [10, 10],
            color: "black",
        }),
        new Coin({ 
            x: 775, 
            y: 400, 
            r: 12, 
            value: 1 
        }),
        new Rectangle({
            pos: [10, 400],
            size: [10, 200],
            color: "blue",
        }),
        new Rectangle({
            pos: [10, 390],
            size: [100, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [0, 370],
            size: [130, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [120, 370],
            size: [10, 220],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 390],
            size: [10, 210],
            color: "blue",
        }),
        new Rectangle({
            pos: [140, 350],
            size: [10, 250],
            color: "blue",
        }),
        new Rectangle({
            pos: [200, 300],
            size: [30, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [300, 330],
            size: [30, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [650, 200],
            size: [30, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [0, 0],
            size: [800, 10],
            color: "blue",
        }),

    ],
    
})
