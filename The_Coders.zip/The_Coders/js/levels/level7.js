import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level7 = new Level({
    size: [1200, 1000],
    objects: [
        new Player({
            pos: [100, 800],
            size: [50, 50]
        }),
        new Goal({
            pos: [1100, 450],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 50, 
            y: 500, 
            r: 12, 
            value: 4 
        }),
        new Box({
            pos: [400, 700],
            size: [200, 100],
            color: "orange",
        }),
        new Box({
            pos: [400, 500],
            size: [100, 70],
            color: "yellow",
        }),
        new Box({
            pos: [400, 300],
            size: [70, 50],
            color: "green",
        }),

    ],
    
})