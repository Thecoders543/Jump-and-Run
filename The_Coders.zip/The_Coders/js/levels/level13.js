import {Level} from "../Level.js";
import {Player} from "../objects/Player.js";
import {Rectangle} from "../objects/Rectangle.js";
import {Box} from "../objects/Box.js";
import {Goal} from "../objects/Goal.js";
import {Coin} from "../objects/Coin.js";

export const level13 = new Level({
    size: [2000, 800],
    objects: [
        new Player({
            pos: [100, 700],
            size: [60, 20]
        }),
        new Goal({
            pos: [0, 150],
            size: [50, 50],
            color: "black",
        }),
        new Coin({ 
            x: 300, 
            y: 30, 
            r: 12, 
            value: 4 
        }),
        new Rectangle({
            pos: [0, 600],
            size: [1900, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 400],
            size: [1900, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 200],
            size: [1800, 10],
            color: "blue",
        }),
        new Rectangle({
            pos: [100, 0],
            size: [10, 200],
            color: "blue",
        }),
    ],
    
})