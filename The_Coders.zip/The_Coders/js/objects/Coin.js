import { ctx } from "../canvas.js";

export class Coin {
    constructor(options) {
        this.x = options.x;
        this.y = options.y;
        this.r = options.r || 10;
        this.value = options.value || 1;
        this.collected = false;
        this.level = null;
        this.type = "Coin";
    }

    draw() {
        if (this.collected) return;
        const camX = this.level ? this.level.cameraPos[0] : 0;
        const camY = this.level ? this.level.cameraPos[1] : 0;

        ctx.beginPath();
        ctx.arc(this.x - camX, this.y - camY, this.r, 0, Math.PI * 2);
        ctx.fillStyle = "#ffd700";
        ctx.fill();
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = "#b8860b";
        ctx.stroke();
        ctx.fillStyle = "#111";
        ctx.font = "12px Arial";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(this.value, this.x - camX, this.y - camY);
    }

    update() {
        if (this.collected) return;
        if (!this.level) return;

        const player = this.level.objectsOfType.Player && this.level.objectsOfType.Player[0];
        if (!player) return;

        const px = player.left + player.size[0] / 2;
        const py = player.top + player.size[1] / 2;
        const dx = px - this.x;
        const dy = py - this.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const pr = Math.max(player.size[0], player.size[1]) / 2;

        if (dist < this.r + pr - 8) {
            let getCoinSound = new Audio("../sounds/get-coin.mp3");
            this.collected = true;

            // Münzzähler aktualisieren
            if (typeof window.addCoins === "function") {
                window.addCoins(this.value);
                getCoinSound.play();
            } else {
                window.coinCount = (window.coinCount || 0) + this.value;
                const el = document.getElementById("coinCount");
                if (el) el.textContent = window.coinCount;
            }
        }
    }

    reset() {
        this.collected = false;
    }
}
