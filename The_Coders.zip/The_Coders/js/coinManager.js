// coinManager.js – globaler Münzzähler
(function(){
    window.coinCount = 0;

    window.addCoins = function(n){
        window.coinCount = (window.coinCount || 0) + n;
        const el = document.getElementById('coinCount');
        if(el) el.textContent = window.coinCount;
    };

    window.setCoins = function(n){
        window.coinCount = n;
        const el = document.getElementById('coinCount');
        if(el) el.textContent = window.coinCount;
    };
})();
