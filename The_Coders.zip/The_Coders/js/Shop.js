// Shop.js – einfacher Shop unter dem Spiel
(function(){
    const SKIN_PRICE = 10;
    const skins = [
        {name: 'Rot', color: 'red'},
        {name: 'Blau', color: 'blue'},
        {name: 'Grün', color: 'green'},
        {name: 'Lila', color: 'purple'},
        {name: 'Orange', color: 'orange'},
        {name: 'Schwarz', color: 'black'}
    ];

    function renderShop(){
        const container = document.getElementById('skins');
        if(!container) return;

        container.innerHTML = '';
        skins.forEach(s => {
            const card = document.createElement('div');
            card.className = 'skin-card';
            card.innerHTML = `
                <div class="skin-swatch" style="background:${s.color}"></div>
                <div class="skin-name">${s.name}</div>
                <div class="skin-price">Preis: ${SKIN_PRICE} Münzen</div>
            `;

            const btn = document.createElement('button');
            btn.className = 'buy-btn';
            btn.textContent = 'Kaufen & Anziehen';

            btn.addEventListener('click', ()=> {
                let buySound = new Audio("../sounds/purchase-success.mp3");
                let notEnoughCoinsSound = new Audio("../sounds/not-enough-coins.mp3");
                if((window.coinCount||0) >= SKIN_PRICE){
                    window.coinCount -= SKIN_PRICE;

                    if(window.game && window.game.currentLevel && window.game.currentLevel.objectsOfType && window.game.currentLevel.objectsOfType.Player){
                        const player = window.game.currentLevel.objectsOfType.Player[0];
                        if(player) player.color = s.color;

                        window.selectedSkinColor = s.color; // speichert den Skin global
                        localStorage.setItem("selectedSkinColor", s.color); // merkt sich die Farbe auch nach Browser-Neustart
                    }

                    const el = document.getElementById('coinCount');
                    if(el) el.textContent = window.coinCount;

                    btn.textContent = 'Angezogen';
                    setTimeout(()=> btn.textContent = 'Kaufen & Anziehen', 800);
                    buySound.play();
                } else {
                    btn.textContent = 'Nicht genug Münzen';
                    setTimeout(()=> btn.textContent = 'Kaufen & Anziehen', 800);
                    notEnoughCoinsSound.play();
                }
            });

            card.appendChild(btn);
            container.appendChild(card);
        });
    }

    window.initShopUI = renderShop;

    document.addEventListener('DOMContentLoaded', renderShop);
})();
