import { game } from "./Game.js";

window.game = game;

game.start();