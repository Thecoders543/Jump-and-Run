export const canvas = document.getElementById("canvas");        //Stellt die einzelnen Objekte dar und wird exportiert, damit es woanders gebraucht werden kann
export const ctx = canvas.getContext("2d");

export function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}