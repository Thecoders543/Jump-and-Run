//Für den Shop

// import {ctx} from "./canvas.js";
// import {Rectangle} from "./objects/Rectangle.js";

/**
 * Coin - einfache sammelbare Münze.
 * - Wird in Levels wie andere Objekte platziert.
 * - Wenn Spieler überlappt -> collect() -> erhöht game.coins (oder ruft game.addCoins)
 */


/**
export class Coin extends Rectangle {
    constructor(options = {}) {
        const {pos = [0, 0], size = [20, 20], value = 1, color = "gold"} = options;
        super({pos, size, color}, "Coin");
        this.value = value;
        this.collected = false;
    }

draw() {
  if (this.collected) return;

  const x = this.pos[0] - this.level.cameraPos[0] + this.size[0] / 2;
  const y = this.pos[1] - this.level.cameraPos[1] + this.size[1] / 2;
  const r = Math.min(this.size[0], this.size[1]) / 2;

  // Goldene Münze
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = "gold";
  ctx.fill();
  ctx.closePath();

  // Glanz-Effekt
  ctx.beginPath();
  ctx.arc(x - r / 3, y - r / 3, r / 3, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(255,255,255,0.6)";
  ctx.fill();
  ctx.closePath();
}


    update(deltaTime) {
        if (this.collected) return;
        if (!this.level || !this.level.player) return;
        
        if (this.overlapsWith(this.level.player)) {
            this.collect();
        }
    }

    collect() {
  if (this.collected) return;
  this.collected = true;

  if (this.level && this.level.game) {
    if (typeof this.level.game.addCoins === "function") {
      this.level.game.addCoins(this.value);
    } else {
      this.level.game.coins = (this.level.game.coins || 0) + this.value;
      try {
        localStorage.setItem("coders_coins", this.level.game.coins);
      } catch (e) {
        console.warn("localStorage nicht verfügbar:", e);
      }
      const el = document.getElementById("coinDisplay");
      if (el) el.innerText = this.level.game.coins;
    }
  }
}




    reset() {
        super.reset();
        this.collected = false;
    }
} */